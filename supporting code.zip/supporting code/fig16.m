scatter3(XYZ(:,1),XYZ(:,2),XYZ(:,3),7,XYZ(:,4),'filled');
c=colorbar;
len=length(XYZ(:,1));
c.Label.String='AbsoluteError';
grid on
axis equal
xlabel("X(mm)")
ylabel("Y(mm)")
zlabel("Z(mm)")
xlim([-5 5])
ylim([-5 5])
zlim([-5 5])

title("Error Distribution")
hold on
[X,Y,Z]=sphere;
r=3.6;
x1=X*r-0.667;
y1=Y*r-0.19;
z1=Z*r-0.161;
mesh(x1,y1,z1)
hidden off
scatter3(XYZ(:,1),XYZ(:,2),-5*ones(1,length(XYZ(:,1))),11,XYZ(:,4),'filled');%xyƽ��
scatter3(XYZ(:,1),5*ones(1,length(XYZ(:,1))),XYZ(:,3),11,XYZ(:,4),'filled');%xzƽ��
scatter3(5*ones(1,length(XYZ(:,1))),XYZ(:,1),XYZ(:,2),11,XYZ(:,4),'filled');%yzƽ��
theta=0:0.01:2*pi;
xc=-0.667+r*sin(theta);
yc=-0.19+r*cos(theta);
ya=-0.19+r*sin(theta);
colors=0*ones(1,length(xc));
scatter3(xc,yc,-5*ones(1,length(xc)),1,colors,'filled');%xyƽ��
zc=-0.161+r*cos(theta);
scatter3(xc,5*ones(1,length(xc)),zc,1,colors,'filled');%xzƽ��
scatter3(5*ones(1,length(xc)),ya,zc,1,colors,'filled');%yzƽ��